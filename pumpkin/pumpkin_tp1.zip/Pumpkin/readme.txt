First Technology Preview of Pumpkin OS.

Please look here first for more information:
https://pmig96.wordpress.com/2021/09/08/pumpkin-os/

Send error reports to:
migueletto@yahoo.com