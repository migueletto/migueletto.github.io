function cleanup_callback()
  if os then
    os.finish()
  end
end

pit.cleanup(cleanup_callback)

pit.loadlib("libbimage")
pit.loadlib("liblsdl2")

pit.mount("./vfs/", "/")

os = pit.loadlib("libos")
os.init()
os.start(1280, 720, 16, false, false, "Launcher")
